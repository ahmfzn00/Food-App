package com.pallangga.foodapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {

    var data: ArrayList<DataModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //inisialisasi array
        data = ArrayList()
        val recyclerView = findViewById(R.id.recyclerView) as RecyclerView

        //simpan data
        data?.add(
            DataModel(R.drawable.rendang, "Rendang", "Rp. 18000", "Mantap")
        )

        data?.add(
            DataModel(R.drawable.rendang, "Coto Makassar", "Rp. 29000", "Mantap")
        )

        data?.add(
            DataModel(R.drawable.rendang, "Soto Lamongan", "Rp. 10000", "Mantap")
        )

        data?.add(
            DataModel(R.drawable.rendang, "Rawon", "Rp. 15000", "Mantap")
        )

        data?.add(
            DataModel(R.drawable.rendang, "Rendang", "Rp. 18000", "Mantap")
        )

        data?.add(
            DataModel(R.drawable.rendang, "Coto Makassar", "Rp. 29000", "Mantap")
        )

        // set recycler view
        recyclerView.adapter = DataAdapter(data, object : DataAdapter.OnClickListener{
            override fun detail(item: DataModel?) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                intent.putExtra("gambar", item?.gambar)
                intent.putExtra("nama", item?.nama)
                intent.putExtra("harga", item?.harga)
                intent.putExtra("keterangan", item?.keterangan)
                startActivity(intent)
            }
        })


    }
}