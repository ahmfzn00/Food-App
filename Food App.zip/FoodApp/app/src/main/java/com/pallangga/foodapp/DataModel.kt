package com.pallangga.foodapp

data class DataModel(
    val gambar: Int,
    val nama: String,
    val harga: String,
    val keterangan: String
);
