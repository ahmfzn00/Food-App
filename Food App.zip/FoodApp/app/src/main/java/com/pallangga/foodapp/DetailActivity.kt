package com.pallangga.foodapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val image = findViewById<ImageView>(R.id.imageViewDetail) as ImageView
        val nama = findViewById<TextView>(R.id.textNamaDetail) as TextView
        val harga = findViewById<TextView>(R.id.textHargaDetail) as TextView
        val keterangan = findViewById<TextView>(R.id.textKetDetail) as TextView

        image.setImageResource(intent.getIntExtra("gambar", R.drawable.rendang))
        nama.text = intent.getStringExtra("nama")
        harga.text = intent.getStringExtra("harga")
        keterangan.text = intent.getStringExtra("keterangan")
    }
}