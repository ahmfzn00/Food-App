package com.pallangga.foodapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataAdapter(val data: List<DataModel>?, val itemClick: OnClickListener) : RecyclerView.Adapter<DataAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list, parent, false) as View

        return MyViewHolder(view)
    }

    override fun getItemCount(): Int = data?.size ?: 0

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = data?.get(position)
        holder.setData(item)
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewNama = itemView.findViewById<TextView>(R.id.textViewNama) as TextView
        val textViewHarga = itemView.findViewById<TextView>(R.id.textViewHarga) as TextView
        val imageView = itemView.findViewById<ImageView>(R.id.imageView) as ImageView
        val buttonView = itemView.findViewById<Button>(R.id.buttonDetail) as Button

        fun setData(item: DataModel?)
        {
            imageView.setImageResource(item?.gambar ?: R.drawable.rendang)
            textViewNama.text = item?.nama
            textViewHarga.text = item?.harga

            buttonView.setOnClickListener {
                itemClick.detail(item)
            }
        }
    }

    interface OnClickListener {
        fun detail (item: DataModel?)
    }
}